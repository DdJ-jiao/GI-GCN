import community
import networkx as nx


def partition_num(num, workers, community_info=None):

    if community_info:

        pass

    if num % workers == 0:
        return [num // workers] * workers
    else:
        return [num // workers] * workers + [num % workers]


def compute_modularity_matrix(graph, partition):

    m = graph.size(weight='weight')
    degrees = dict(graph.degree(weight='weight'))
    Q_dict = {}

    for u in graph.nodes():
        for v in graph.nodes():
            same_community = int(partition[u] == partition[v])
            if same_community:
                A_uv = graph[u][v]['weight'] if graph.has_edge(u, v) else 0.0
                k_u = degrees[u]
                k_v = degrees[v]
                Q_uv = (A_uv - (k_u * k_v) / (2.0 * m)) / (2.0 * m)
                Q_dict[(u, v)] = Q_uv
    return Q_dict
