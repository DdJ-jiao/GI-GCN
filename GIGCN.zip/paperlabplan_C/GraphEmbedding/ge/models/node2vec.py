
from gensim.models import Word2Vec
from ..walker import RandomWalker
import pandas as pd
import pickle
import networkx as nx
import community
from ..utils import compute_modularity_matrix
class Node2Vec:

    def __init__(self, graph, walk_length, num_walks, p=1.0, q=1.0, workers=1):
        self.graph = graph
        self._embeddings = {}
        self.partition = community.best_partition(self.graph)
        self.enhanced_graph = self.enhance_graph_with_community_info(self.graph, self.partition)
        Q_dict = compute_modularity_matrix(self.enhanced_graph, self.partition)
        self.walker = RandomWalker(self.enhanced_graph, p=p, q=q, Q_dict=Q_dict)
        self.walker.preprocess_transition_probs()
        self.sentences = self.walker.simulate_walks(
            num_walks=num_walks, walk_length=walk_length, workers=workers, verbose=1)

    def enhance_graph_with_community_info(self, graph, community_partition):
        enhanced_G = nx.Graph()
        for u, v, data in graph.edges(data=True):
            enhanced_G.add_edge(u, v, weight=data.get('weight', 1))
        for node in graph.nodes:
            community_id = community_partition[node]
            for other_node in graph.nodes:
                if community_partition.get(other_node) == community_id and node != other_node:
                    enhanced_G.add_edge(node, other_node, weight=1.0)  # **可以调节权重大小**

        return enhanced_G

    def train(self, embed_size=256, window_size=5, workers=3, iter=5, **kwargs):
        kwargs["sentences"] = self.sentences
        kwargs["min_count"] = kwargs.get("min_count", 0)
        kwargs["size"] = embed_size
        kwargs["sg"] = 1
        kwargs["hs"] = 0
        kwargs["workers"] = workers
        kwargs["window"] = window_size
        kwargs["iter"] = iter
        model = Word2Vec(**kwargs)
        self.w2v_model = model
        model.save("../../processed/node2vec/2w_node2vecmodel_256.bin")
        return model

    def get_embeddings(self,):

        modelload = Word2Vec.load("../../processed/node2vec/2w_node2vecmodel_256.bin")
        self._embeddings = {}
        for word in self.graph.nodes():
            self._embeddings[word] = modelload.wv[word]
        print(self._embeddings)
        print(type(self._embeddings))
        return self._embeddings

    def dumpembeddings(self,):

        modelload = Word2Vec.load("../../processed/node2vec/2w_node2vecmodel_256.bin")
        self._embeddings = {}
        for word in self.graph.nodes():
            self._embeddings[word] = modelload.wv[word]
        with open("../../processed/node2vec/2w_node2vecembeddingsdict_256.dat", 'wb') as fw:
            print(self._embeddings)
            pickle.dump(self._embeddings, fw)
