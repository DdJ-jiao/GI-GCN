
from .node2vec import Node2Vec

__all__ = [ "Node2Vec",]
