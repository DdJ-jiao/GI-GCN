import numpy as np
import scipy.sparse as sp
import torch
import random
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import precision_score, recall_score, f1_score

import matplotlib.pyplot as plt

def encode_onehot(labels):
    classes = set(labels)

    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in
                    enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)),
                             dtype=np.int32)
    return labels_onehot



def load_data(path="../data/add/", datasetcontent="new_labeled",
                  datasetsite='topic1_relation'):

    print('Loading {} dataset...')

    idx_features_labels = np.genfromtxt("{}{}.content".format(path, datasetcontent),
                                        dtype=np.dtype(str))

    np.random.shuffle(idx_features_labels)

    features = sp.csr_matrix(idx_features_labels[:, 1:-1], dtype=np.float32)

    print(features.todense())
    labels = encode_onehot(idx_features_labels[:, -1])

    idx = np.array(idx_features_labels[:, 0], dtype=np.int32)
    print(idx)
    idx_map = {j: i for i, j in enumerate(idx)}
    print(idx_map)
    edges_unordered = np.genfromtxt("{}{}.cites".format(path, datasetsite),
                                    dtype=np.int32)
    edges = np.array(list(map(idx_map.get, edges_unordered.flatten())),
                     dtype=np.float32).reshape(edges_unordered.shape)
    adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                        shape=(labels.shape[0], labels.shape[0]),
                        dtype=np.float32)


    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)

    features = normalize(features)
    adj = normalize(adj + sp.eye(adj.shape[0]))



    idx = list(range(2723))
    idx_test= random.sample(idx,200)

    idx_train = [i for i in idx if i not in idx_test]



    features = torch.FloatTensor(np.array(features.todense()))
    labels = torch.LongTensor(np.where(labels)[1])
    print(labels)
    adj = sparse_mx_to_torch_sparse_tensor(adj)

    idx_train = torch.LongTensor(idx_train)

    idx_test = torch.LongTensor(idx_test)

    return adj, features, labels, idx_train,  idx_test


def normalize(mx):

    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def accuracy1 (output, labels):
    outputnp = output.max(1)[1].type_as(labels).cpu().data.numpy().tolist()

    labelsnp = labels.cpu().data.numpy().tolist()
    acc = accuracy_score(outputnp, labelsnp)
    return acc

def precrecallf1(output, labels):
    outputnp = output.max(1)[1].type_as(labels).cpu().data.numpy().tolist()
    labelsnp = labels.cpu().data.numpy().tolist()
    p = precision_score(labelsnp, outputnp)
    r = recall_score(labelsnp, outputnp)
    f1 = f1_score(labelsnp, outputnp)
    return p,r,f1




def classreport(output, labels):
     outputnp = output.max(1)[1].type_as(labels).cpu().data.numpy().tolist()

     labelsnp = labels.cpu().data .numpy().tolist()



     target_names = ['class 0', 'class 1']

     return classification_report(outputnp, labelsnp, target_names=target_names)



if __name__ == '__main__':
     load_data()