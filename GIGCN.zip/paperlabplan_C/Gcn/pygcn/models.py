import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_scatter import scatter_add
from Gcn.pygcn.layers import GraphConvolution

class GCN(nn.Module):
    def __init__(self,
                 num_features: int,
                 num_communities: int = 20,
                 hidden_dim: int = 64,
                 num_classes: int = 1,
                 dropout: float = 0.5,
                 time_decay_init: float = 0.1):

        super().__init__()


        self.comm_embed = nn.Embedding(num_communities, hidden_dim // 4)


        self.feature_enhance = nn.Linear(num_features + hidden_dim // 4, hidden_dim)


        self.gcn1 = GCNConv(hidden_dim, hidden_dim)
        self.gcn2 = GCNConv(hidden_dim, hidden_dim)


        self.time_decay = nn.Parameter(torch.tensor([time_decay_init]))


        self.attn = nn.Linear(2 * hidden_dim, 1)


        self.predictor = nn.Sequential(
            nn.Linear(hidden_dim, 32),
            nn.ReLU(),
            nn.Linear(32, num_classes))


        self.dropout = dropout

    def forward(self, x, edge_index, community_ids, edge_time):

        comm_features = self.comm_embed(community_ids)
        enhanced_x = torch.cat([x, comm_features], dim=1)
        enhanced_x = F.relu(self.feature_enhance(enhanced_x))


        x_gcn1 = F.relu(self.gcn1(enhanced_x, edge_index))
        x_gcn1 = F.dropout(x_gcn1, p=self.dropout, training=self.training)


        x_gcn2 = F.relu(self.gcn2(x_gcn1, edge_index))


        decay = torch.exp(-self.time_decay * edge_time)


        src, dst = edge_index
        combined = torch.cat([x_gcn2[src], x_gcn2[dst]], dim=1)
        attn_weights = torch.sigmoid(self.attn(combined)).squeeze()


        aggregated = scatter_add(x_gcn2[src] * attn_weights * decay, dst, dim=0)


        output = self.predictor(aggregated)
        return torch.sigmoid(output.squeeze())